package idea;

public interface Component {

}
