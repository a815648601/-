package idea;

public interface Finery {

}
