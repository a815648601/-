package idea4;

public class Boss {

}
