package idea2;

public class VolunteerFactory {

}
