package idea2;

public class Volunteer {

}
