package idea2;

public interface IFactory {

}
