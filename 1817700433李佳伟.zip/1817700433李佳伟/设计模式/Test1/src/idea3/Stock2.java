
public class Stock2 {

}
