/**
 * @Classname Main
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 14:57
 */
public class Main {
	public static void main(String[] args) {
		Fund jijin = new Fund();
		jijin.buyFund();
		jijin.sellFund();
	}
}
