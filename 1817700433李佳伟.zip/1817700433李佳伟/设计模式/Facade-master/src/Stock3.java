/**
 * @Classname Stock3
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 15:01
 */
public class Stock3 {
    public void sell()
    {
        System.out.println("股票3卖出");
    }

    public void buy()
    {
        System.out.println("股票3买入");
    }
}
