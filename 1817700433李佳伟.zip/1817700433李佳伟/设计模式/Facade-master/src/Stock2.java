/**
 * @Classname Stock2
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 14:59
 */
public class Stock2 {
    public void sell()
    {
        System.out.println("股票2卖出");
    }

    public void buy()
    {
        System.out.println("股票2买入");
    }
}
