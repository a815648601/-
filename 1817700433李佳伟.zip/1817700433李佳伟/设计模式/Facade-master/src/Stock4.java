/**
 * @Classname Stock4
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 15:03
 */
public class Stock4 {
    public void sell()
    {
        System.out.println("股票4卖出");
    }

    public void buy()
    {
        System.out.println("股票4买入");
    }
}
