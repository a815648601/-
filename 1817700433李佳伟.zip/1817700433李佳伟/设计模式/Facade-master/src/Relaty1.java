/**
 * @Classname Relaty1
 * @Description TODO
 * @Author 马维俊
 * @Version V1.0.0
 * @Date 2019/5/6 15:06
 */
public class Relaty1
{
    public void sell()
    {
        System.out.println("房地产1卖出");
    }

    public void buy()
    {
        System.out.println("房地产1买入");
    }
}

